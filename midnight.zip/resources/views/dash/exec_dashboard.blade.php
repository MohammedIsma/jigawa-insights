@extends('layouts.app-dashboard')

@section('Content')
    <lgasummary-dashboard-component></lgasummary-dashboard-component>
@endsection
