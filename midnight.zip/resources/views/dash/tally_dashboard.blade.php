@extends('layouts.app-dashboard')

@section('Content')
    <tally-dashboard-component></tally-dashboard-component>
@endsection
