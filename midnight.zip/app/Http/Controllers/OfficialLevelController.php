<?php

namespace App\Http\Controllers;

use App\Models\OfficialLevel;
use Illuminate\Http\Request;

class OfficialLevelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\OfficialLevel  $officialLevel
     * @return \Illuminate\Http\Response
     */
    public function show(OfficialLevel $officialLevel)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\OfficialLevel  $officialLevel
     * @return \Illuminate\Http\Response
     */
    public function edit(OfficialLevel $officialLevel)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\OfficialLevel  $officialLevel
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, OfficialLevel $officialLevel)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\OfficialLevel  $officialLevel
     * @return \Illuminate\Http\Response
     */
    public function destroy(OfficialLevel $officialLevel)
    {
        //
    }
}
